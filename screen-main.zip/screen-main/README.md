@oclif/screen
=============

get stdout/stderr columns

[![Version](https://img.shields.io/npm/v/@oclif/screen.svg)](https://npmjs.org/package/@oclif/screen)
[![CircleCI](https://circleci.com/gh/oclif/screen/tree/main.svg?style=svg)](https://circleci.com/gh/oclif/screen/tree/main)
[![Appveyor CI](https://ci.appveyor.com/api/projects/status/github/oclif/screen?branch=main&svg=true)](https://ci.appveyor.com/project/heroku/screen/branch/main)
[![Known Vulnerabilities](https://snyk.io/test/npm/@oclif/screen/badge.svg)](https://snyk.io/test/npm/@oclif/screen)
[![Downloads/week](https://img.shields.io/npm/dw/@oclif/screen.svg)](https://npmjs.org/package/@oclif/screen)
[![License](https://img.shields.io/npm/l/@oclif/screen.svg)](https://github.com/oclif/screen/blob/main/package.json)
