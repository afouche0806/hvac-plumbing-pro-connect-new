## [3.0.8](https://github.com/oclif/screen/compare/3.0.7...3.0.8) (2023-10-18)


### Bug Fixes

* **deps:** bump @babel/traverse from 7.16.3 to 7.23.2 ([97928c8](https://github.com/oclif/screen/commit/97928c85daebbe8748050e8265e65f6a0a621a2f))



## [3.0.7](https://github.com/oclif/screen/compare/3.0.6...3.0.7) (2023-09-28)


### Bug Fixes

* **deps:** bump get-func-name from 2.0.0 to 2.0.2 ([cc52af3](https://github.com/oclif/screen/commit/cc52af311dcdc528985aae1b67f7a31b9c8915ab))



## [3.0.6](https://github.com/oclif/screen/compare/3.0.5...3.0.6) (2023-07-19)


### Bug Fixes

* **deps:** bump word-wrap from 1.2.3 to 1.2.4 ([ac491a9](https://github.com/oclif/screen/commit/ac491a9eed118d398536425ce8610ace5d2ccb95))



## [3.0.5](https://github.com/oclif/screen/compare/3.0.4...3.0.5) (2023-07-12)


### Bug Fixes

* **deps:** bump semver from 5.7.1 to 5.7.2 ([9abb8c8](https://github.com/oclif/screen/commit/9abb8c8c567bc9f870d1c064e422cd5dffa11a8e))



## [3.0.4](https://github.com/oclif/screen/compare/3.0.3...3.0.4) (2023-01-01)


### Bug Fixes

* **deps:** bump json5 from 2.2.0 to 2.2.3 ([481badc](https://github.com/oclif/screen/commit/481badc6f4db415a610970fab451ca16e86a5bfc))



## [3.0.3](https://github.com/oclif/screen/compare/v3.0.2...3.0.3) (2022-10-30)


### Bug Fixes

* **deps:** bump minimist from 1.2.5 to 1.2.7 ([faa0c93](https://github.com/oclif/screen/commit/faa0c934b202ede963197a68ccfbb67c4f1e1c3d))



## [3.0.2](https://github.com/oclif/screen/compare/v1.0.4...v3.0.2) (2021-12-08)



## [1.0.4](https://github.com/oclif/screen/compare/v1.0.3...v1.0.4) (2018-10-13)


### Bug Fixes

* remove greenkeeper badge ([c2ab678](https://github.com/oclif/screen/commit/c2ab678c83d033c86263ff86700476d4b15cd954))



## [1.0.3](https://github.com/oclif/screen/compare/v1.0.2...v1.0.3) (2018-09-14)


### Bug Fixes

* updated deps ([181503b](https://github.com/oclif/screen/commit/181503b7836a4c281bbdb1248c1f0a8bd1736c1f))



## [1.0.2](https://github.com/oclif/screen/compare/v1.0.1...v1.0.2) (2018-02-14)


### Bug Fixes

* greenkeeper ([5f7a357](https://github.com/oclif/screen/commit/5f7a3571831262c69ed385a6a4b19d23309ea670))



## [1.0.1](https://github.com/oclif/screen/compare/v1.0.0...v1.0.1) (2018-02-13)


### Bug Fixes

* testing release ([b4a85c0](https://github.com/oclif/screen/commit/b4a85c00ab0a24f44654926e14810ba8e3917f73))



# [1.0.0](https://github.com/oclif/screen/compare/v0.0.3...v1.0.0) (2018-02-13)


### Bug Fixes

* rename to oclif ([03f63be](https://github.com/oclif/screen/commit/03f63beb2d15a7f51f79e765df150719e81320de))



## [0.0.3](https://github.com/oclif/screen/compare/v0.0.2...v0.0.3) (2018-01-31)


### Bug Fixes

* triggering release ([1d98378](https://github.com/oclif/screen/commit/1d98378336df3c0a967963b030bb4c5770c7598b))



## [0.0.2](https://github.com/oclif/screen/compare/v0.0.1...v0.0.2) (2018-01-28)


### Bug Fixes

* ran generator ([ccb7680](https://github.com/oclif/screen/commit/ccb7680b06adf1fd960056c22c43c2a0217d5fb4))



## [0.0.1](https://github.com/oclif/screen/compare/v0.0.0...v0.0.1) (2018-01-20)


### Bug Fixes

* ran generator ([0917152](https://github.com/oclif/screen/commit/09171522721e229a5052f647821d05bfb7f8271a))



# [0.0.0](https://github.com/oclif/screen/compare/15d3f0d4ed23bddcb16cecc4c070974689350c9a...v0.0.0) (2018-01-14)


### Features

* dxcli-ify ([15d3f0d](https://github.com/oclif/screen/commit/15d3f0d4ed23bddcb16cecc4c070974689350c9a))



